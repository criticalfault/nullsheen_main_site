You need to place files in multiple locations:

All DAT files go into the ./DATA directory
Notes.txt goes into the main application directory
INIT.RTF goes in the ./SR3 directory
All GIFS and BMP go in the ./HTML directory

and of course, the NSRCG.EXE goes in the main application directory.
